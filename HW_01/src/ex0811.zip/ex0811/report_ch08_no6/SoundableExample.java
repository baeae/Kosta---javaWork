package ex0811.report_ch08_no6;

public class SoundableExample {
	
	public static void printSound(Soundable soundable) {
		System.out.println(soundable.sound());
	}

	public static void main(String[] args) {
		
		printSound(new Cat());
		printSound(new Dog());
		

	}

}
